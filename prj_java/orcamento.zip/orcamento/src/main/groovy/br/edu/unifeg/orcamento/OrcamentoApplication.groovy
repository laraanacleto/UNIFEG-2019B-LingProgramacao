package br.edu.unifeg.orcamento

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class OrcamentoApplication {

	static void main(String[] args) {
		SpringApplication.run(OrcamentoApplication, args)
	}

}
